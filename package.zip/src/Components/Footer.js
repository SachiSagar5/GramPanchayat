import React from'react'

export default function footer(){
    return(
        <div style={{ textAlign: 'center' }}>Copyright ©2020 Thantrick Business Solution, All Right reserved</div>
    )
}